import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  loginSchema, registerSchema, insertInvestmentSchema, 
  depositSchema, withdrawalSchema 
} from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";
import bcrypt from "bcrypt";

// Authentication middleware
const requireAuth = (req: Request, res: Response, next: Function) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Требуется авторизация" });
  }
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const SessionStore = MemoryStore(session);

  // Setup session middleware
  app.use(
    session({
      cookie: { maxAge: 86400000 }, // 24 hours
      store: new SessionStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      resave: false,
      saveUninitialized: false,
      secret: process.env.SESSION_SECRET || "cryptovest-secret",
    })
  );

  // ========== User Auth Routes ==========
  
  // Register
  app.post("/api/auth/register", async (req, res) => {
    try {
      const data = registerSchema.parse(req.body);
      
      // Check if email already exists
      const existingUser = await storage.getUserByEmail(data.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email уже зарегистрирован" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(data.password, 10);
      
      // Create user
      const user = await storage.createUser(
        { 
          username: data.username, 
          email: data.email, 
          password: hashedPassword 
        },
        data.referralCode
      );
      
      // Handle referral if code provided
      if (data.referralCode) {
        const referrer = await storage.getUserByReferralCode(data.referralCode);
        if (referrer) {
          // Create referral record
          await storage.createReferral({
            referrerId: referrer.id,
            referredId: user.id,
          });
          
          // Add referral bonus transaction
          const bonusAmount = 15; // 15 USDT bonus
          await storage.createTransaction({
            userId: referrer.id,
            type: "referral",
            amount: bonusAmount,
            status: "completed"
          });
          
          // Update referrer balance
          await storage.updateUserBalance(referrer.id, bonusAmount);
        }
      }
      
      // Set session
      req.session.userId = user.id;
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  // Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const data = loginSchema.parse(req.body);
      
      // Find user by email
      const user = await storage.getUserByEmail(data.email);
      if (!user) {
        return res.status(400).json({ message: "Неверный email или пароль" });
      }
      
      // Check password
      const passwordMatch = await bcrypt.compare(data.password, user.password);
      if (!passwordMatch) {
        return res.status(400).json({ message: "Неверный email или пароль" });
      }
      
      // Set session
      req.session.userId = user.id;
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  // Get current user
  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Не авторизован" });
    }
    
    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        req.session.destroy(() => {});
        return res.status(401).json({ message: "Пользователь не найден" });
      }
      
      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Logout
  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.status(200).json({ message: "Выход выполнен успешно" });
    });
  });

  // ========== Investment Routes ==========
  
  // Get user investments
  app.get("/api/investments", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const investments = await storage.getInvestments(userId);
      res.json(investments);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Create new investment
  app.post("/api/investments", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const data = insertInvestmentSchema.parse(req.body);
      
      // Check if user has enough balance
      const user = await storage.getUser(userId);
      if (!user || user.balance < data.amount) {
        return res.status(400).json({ message: "Недостаточно средств" });
      }
      
      // Create investment
      const investment = await storage.createInvestment({
        userId,
        amount: data.amount
      });
      
      // Update user balance
      await storage.updateUserBalance(userId, -data.amount);
      
      // Create transaction record
      await storage.createTransaction({
        userId,
        type: "investment",
        amount: -data.amount,
        status: "completed"
      });
      
      // Update VIP level if necessary
      // Calculate total investments
      const investments = await storage.getInvestments(userId);
      const totalInvested = investments.reduce((sum, inv) => sum + inv.amount, 0);
      
      let newVipLevel = 1;
      if (totalInvested >= 3000) newVipLevel = 6;
      else if (totalInvested >= 2000) newVipLevel = 5;
      else if (totalInvested >= 1000) newVipLevel = 4;
      else if (totalInvested >= 500) newVipLevel = 3;
      else if (totalInvested >= 300) newVipLevel = 2;
      
      if (newVipLevel > user.vipLevel) {
        await storage.updateUserVipLevel(userId, newVipLevel);
      }
      
      res.status(201).json(investment);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  // ========== Transaction Routes ==========
  
  // Get user transactions
  app.get("/api/transactions", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const transactions = await storage.getTransactions(userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // Deposit
  app.post("/api/transactions/deposit", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const data = depositSchema.parse(req.body);
      
      // Create pending transaction
      const transaction = await storage.createTransaction({
        userId,
        type: "deposit",
        amount: data.amount,
        status: "pending"
      });
      
      // In a real app, we would integrate with a payment gateway here
      // For this demo, we'll just approve the deposit immediately
      
      // Update transaction status
      const updatedTransaction = await storage.updateTransactionStatus(transaction.id, "completed");
      
      // Update user balance
      await storage.updateUserBalance(userId, data.amount);
      
      res.status(201).json(updatedTransaction);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  // Withdrawal
  app.post("/api/transactions/withdraw", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const data = withdrawalSchema.parse(req.body);
      
      // Get user
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }
      
      // Check balance
      if (user.balance < data.amount) {
        return res.status(400).json({ message: "Недостаточно средств" });
      }
      
      // Check withdrawal limits
      if (data.amount < 70) {
        return res.status(400).json({ message: "Минимальная сумма вывода 70 USDT" });
      }
      
      // Check if withdrawal is allowed (once per week)
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      
      if (user.lastWithdrawal && user.lastWithdrawal > oneWeekAgo) {
        return res.status(400).json({ 
          message: "Вывод возможен только раз в неделю" 
        });
      }
      
      // Create pending transaction
      const transaction = await storage.createTransaction({
        userId,
        type: "withdrawal",
        amount: -data.amount,
        status: "pending"
      });
      
      // In a real app, we would process the withdrawal through a payment gateway
      // For this demo, we'll just approve it immediately
      
      // Update transaction status
      const updatedTransaction = await storage.updateTransactionStatus(transaction.id, "completed");
      
      // Update user balance
      await storage.updateUserBalance(userId, -data.amount);
      
      // Update last withdrawal date
      await storage.updateUserLastWithdrawal(userId);
      
      res.status(201).json(updatedTransaction);
    } catch (error) {
      res.status(400).json({ message: error.message });
    }
  });

  // ========== Referral Routes ==========
  
  // Get user referrals
  app.get("/api/referrals", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const referrals = await storage.getReferrals(userId);
      const referralCount = referrals.length;
      
      // Calculate total earned from referrals
      const referralTransactions = (await storage.getTransactions(userId))
        .filter(t => t.type === "referral" && t.status === "completed");
      
      const totalEarned = referralTransactions.reduce((sum, t) => sum + t.amount, 0);
      
      res.json({
        referrals,
        count: referralCount,
        totalEarned
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  // ========== Daily profit calculation ==========
  // This would typically be done by a cron job in a real app
  // For simplicity, we'll implement an endpoint that simulates daily profit calculation
  
  app.post("/api/simulate-daily-profit", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      
      // Get user and active investments
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Пользователь не найден" });
      }
      
      const investments = await storage.getInvestments(userId);
      const activeInvestments = investments.filter(inv => inv.status === "active");
      
      if (activeInvestments.length === 0) {
        return res.status(400).json({ message: "Нет активных инвестиций" });
      }
      
      // Calculate daily profit based on VIP level
      const rates = {
        1: 0.012, // 1.2%
        2: 0.014, // 1.4%
        3: 0.016, // 1.6%
        4: 0.018, // 1.8%
        5: 0.020, // 2.0%
        6: 0.022  // 2.2%
      };
      
      const rate = rates[user.vipLevel] || rates[1];
      const totalInvested = activeInvestments.reduce((sum, inv) => sum + inv.amount, 0);
      const dailyProfit = totalInvested * rate;
      
      // Create profit transaction
      await storage.createTransaction({
        userId,
        type: "profit",
        amount: dailyProfit,
        status: "completed"
      });
      
      // Update user balance
      await storage.updateUserBalance(userId, dailyProfit);
      
      res.json({
        profit: dailyProfit,
        rate: rate * 100,
        totalInvested
      });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  });

  return httpServer;
}
