import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { FaCheck } from 'react-icons/fa';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';

interface VipLevelCardProps {
  level: number;
  dailyReturn: number;
  minDeposit: number;
  popular?: boolean;
  features: string[];
}

const VipLevelCard: React.FC<VipLevelCardProps> = ({
  level,
  dailyReturn,
  minDeposit,
  popular = false,
  features,
}) => {
  const [, setLocation] = useLocation();
  const { user } = useAuth();

  const handleInvestClick = () => {
    if (user) {
      setLocation('/dashboard');
    } else {
      setLocation('/register');
    }
  };

  const getBgColor = () => {
    switch (level) {
      case 1: return 'bg-primary-900';
      case 2: return 'bg-primary-800';
      case 3: return 'bg-primary-700';
      case 4: return 'bg-primary-600';
      case 5: return 'bg-primary-500';
      case 6: return 'bg-secondary-600';
      default: return 'bg-primary-900';
    }
  };

  return (
    <div className={`bg-dark-800 border ${popular ? 'border-primary-700' : 'border-dark-600'} rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition duration-300 relative`}>
      {popular && (
        <div className="absolute top-0 right-0 bg-secondary-500 text-white text-xs font-bold px-2 py-1 rounded-bl">
          Популярный
        </div>
      )}
      <div className={`${getBgColor()} px-6 py-4`}>
        <h3 className="text-xl font-bold text-white text-center">VIP {level}</h3>
      </div>
      <div className="p-6">
        <div className="text-center mb-4">
          <p className="text-3xl font-bold text-primary-400">{dailyReturn}%</p>
          <p className="text-dark-300">Ежедневный доход</p>
        </div>
        <ul className="text-dark-200 space-y-2 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center">
              <FaCheck className="text-green-500 mr-2 flex-shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
        <Button 
          className="w-full bg-primary-600 hover:bg-primary-500 text-white"
          onClick={handleInvestClick}
        >
          Инвестировать
        </Button>
      </div>
    </div>
  );
};

export default VipLevelCard;
