import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { FaTimes, FaExclamationTriangle } from 'react-icons/fa';
import { useToast } from '@/hooks/use-toast';

interface WithdrawalModalProps {
  isOpen: boolean;
  onClose: () => void;
  onWithdraw: (amount: number, address: string) => Promise<void>;
  balance: number;
  lastWithdrawal: Date | null;
}

const WithdrawalModal: React.FC<WithdrawalModalProps> = ({ 
  isOpen, 
  onClose, 
  onWithdraw,
  balance,
  lastWithdrawal
}) => {
  const { toast } = useToast();
  const [amount, setAmount] = useState<number>(70);
  const [walletAddress, setWalletAddress] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState(false);

  const canWithdraw = () => {
    if (lastWithdrawal) {
      const oneWeekAgo = new Date();
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
      if (new Date(lastWithdrawal) > oneWeekAgo) {
        return false;
      }
    }
    return true;
  };

  const withdrawalAllowed = canWithdraw();
  const nextWithdrawalDate = lastWithdrawal ? new Date(lastWithdrawal.getTime() + 7 * 24 * 60 * 60 * 1000) : null;

  const handleWithdraw = async () => {
    if (amount < 70) {
      toast({
        title: "Ошибка",
        description: "Минимальная сумма вывода 70 USDT",
        variant: "destructive",
      });
      return;
    }

    if (amount > balance) {
      toast({
        title: "Ошибка",
        description: "Недостаточно средств на балансе",
        variant: "destructive",
      });
      return;
    }

    if (!walletAddress) {
      toast({
        title: "Ошибка",
        description: "Введите адрес кошелька",
        variant: "destructive",
      });
      return;
    }

    if (!withdrawalAllowed) {
      toast({
        title: "Ошибка",
        description: "Вывод средств доступен только раз в неделю",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    try {
      await onWithdraw(amount, walletAddress);
      toast({
        title: "Вывод успешен",
        description: `${amount} USDT успешно выведено на ваш кошелек`,
      });
      onClose();
    } catch (error) {
      toast({
        title: "Ошибка",
        description: error.message || "Произошла ошибка при выводе средств",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-dark-800 text-white border-dark-700 sm:max-w-md">
        <DialogHeader>
          <div className="flex justify-between items-center mb-2">
            <DialogTitle className="text-xl font-bold text-white">Вывод средств</DialogTitle>
            <DialogClose className="text-dark-400 hover:text-white">
              <FaTimes />
            </DialogClose>
          </div>
        </DialogHeader>
        
        <div className="space-y-4">
          {!withdrawalAllowed && nextWithdrawalDate && (
            <div className="bg-red-900/30 border border-red-700 rounded-lg p-4 mb-4">
              <div className="flex items-center text-red-400 mb-1">
                <FaExclamationTriangle className="mr-2" />
                <span className="font-medium">Вывод недоступен</span>
              </div>
              <p className="text-xs text-dark-300">
                Вывод средств доступен только раз в неделю. Следующий вывод будет доступен: {nextWithdrawalDate.toLocaleDateString()}
              </p>
            </div>
          )}
          
          <div>
            <Label htmlFor="withdraw-amount" className="text-dark-200">Сумма в USDT</Label>
            <Input 
              id="withdraw-amount" 
              type="number" 
              min="70"
              max={balance}
              value={amount} 
              onChange={(e) => setAmount(parseFloat(e.target.value))} 
              className="bg-dark-700 border-dark-600 text-white mt-1"
            />
            <div className="flex justify-between text-xs mt-1">
              <span className="text-dark-400">Минимум: 70 USDT</span>
              <span className="text-dark-400">Доступно: {balance.toFixed(2)} USDT</span>
            </div>
          </div>
          
          <div>
            <Label htmlFor="wallet-address" className="text-dark-200">USDT TRC20 адрес кошелька</Label>
            <Input 
              id="wallet-address" 
              value={walletAddress} 
              onChange={(e) => setWalletAddress(e.target.value)} 
              className="bg-dark-700 border-dark-600 text-white mt-1"
              placeholder="TRC20 адрес (начинается с T)"
            />
          </div>
          
          <div className="bg-dark-700 rounded-lg p-4">
            <div className="flex items-center text-yellow-400 mb-2">
              <FaExclamationTriangle className="mr-2" />
              <span className="font-medium">Важно!</span>
            </div>
            <p className="text-xs text-dark-300">
              Убедитесь, что вы указали правильный адрес кошелька. Транзакции в блокчейне необратимы.
            </p>
          </div>
        </div>
        
        <Button
          className="w-full bg-primary-600 hover:bg-primary-500 text-white font-medium py-3 mt-4"
          onClick={handleWithdraw}
          disabled={isProcessing || amount < 70 || amount > balance || !walletAddress || !withdrawalAllowed}
        >
          {isProcessing ? "Обработка..." : "Вывести средства"}
        </Button>
      </DialogContent>
    </Dialog>
  );
};

export default WithdrawalModal;
