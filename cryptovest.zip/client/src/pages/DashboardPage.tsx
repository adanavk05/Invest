import React, { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useInvestment } from '@/hooks/useInvestment';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import {
  FaWallet,
  FaCrown,
  FaUsers,
  FaChartLine,
  FaArrowDown,
  FaArrowRight,
  FaCoins,
  FaCopy,
  FaPlus,
  FaSignOutAlt,
} from 'react-icons/fa';
import WalletModal from '@/components/WalletModal';
import DepositModal from '@/components/DepositModal';
import WithdrawalModal from '@/components/WithdrawalModal';
import { formatDate } from '@/lib/utils';

const DashboardPage: React.FC = () => {
  const { user, logout } = useAuth();
  const { 
    investments, 
    transactions, 
    referrals, 
    isLoading,
    simulateDailyProfit,
    makeDeposit,
    makeWithdrawal,
    createInvestment,
  } = useInvestment();
  const { toast } = useToast();

  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isWithdrawalModalOpen, setIsWithdrawalModalOpen] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);

  // Calculate VIP progress
  const vipLevels = [
    { level: 1, required: 50 },
    { level: 2, required: 300 },
    { level: 3, required: 1000 },
    { level: 4, required: 2000 },
    { level: 5, required: 3000 },
    { level: 6, required: 5000 }
  ];

  const totalInvested = investments?.reduce((sum, inv) => sum + inv.amount, 0) || 0;
  
  const currentVipLevel = user?.vipLevel || 1;
  const nextVipLevel = currentVipLevel < 6 ? currentVipLevel + 1 : 6;
  const requiredForNextLevel = vipLevels.find(vl => vl.level === nextVipLevel)?.required || 0;
  const progressPercentage = Math.min(100, (totalInvested / requiredForNextLevel) * 100);

  // Handle referral link copy
  const handleCopyReferralLink = () => {
    if (user) {
      const referralLink = `${window.location.origin}/register?ref=${user.referralCode}`;
      navigator.clipboard.writeText(referralLink);
      toast({
        title: "Скопировано!",
        description: "Реферальная ссылка скопирована в буфер обмена",
      });
    }
  };

  // Handle simulating daily profit
  const handleSimulateDailyProfit = async () => {
    try {
      const result = await simulateDailyProfit();
      toast({
        title: "Ежедневный доход начислен",
        description: `Вы получили ${result.profit.toFixed(2)} USDT (${result.rate}%)`,
      });
    } catch (error) {
      toast({
        title: "Ошибка",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  // Calculate profits and summaries
  const weeklyProfit = transactions
    ?.filter(t => t.type === 'profit' && new Date(t.createdAt) > new Date(Date.now() - 7 * 24 * 60 * 60 * 1000))
    .reduce((sum, t) => sum + t.amount, 0) || 0;

  const monthlyProfit = transactions
    ?.filter(t => t.type === 'profit' && new Date(t.createdAt) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000))
    .reduce((sum, t) => sum + t.amount, 0) || 0;

  const totalProfit = transactions
    ?.filter(t => t.type === 'profit')
    .reduce((sum, t) => sum + t.amount, 0) || 0;

  const availableForWithdrawal = user?.balance || 0;

  if (isLoading || !user) {
    return <div className="flex justify-center items-center min-h-screen bg-dark-900">Загрузка...</div>;
  }

  const getDailyRateByVipLevel = (level: number) => {
    const rates = {
      1: 1.2,
      2: 1.4,
      3: 1.6,
      4: 1.8,
      5: 2.0,
      6: 2.2
    };
    return rates[level] || 1.2;
  };

  return (
    <div className="bg-dark-900 min-h-screen animate-fade-in">
      <header className="bg-dark-800 shadow-md">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          <h1 className="text-xl font-bold font-heading text-white">Личный кабинет</h1>
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center">
              <span className="text-dark-300 mr-2">Баланс:</span>
              <span className="font-medium text-white">{user.balance.toFixed(2)} USDT</span>
            </div>
            <div className="bg-primary-700 text-white px-3 py-1 rounded-full text-sm flex items-center">
              <span>VIP</span>
              <span className="ml-1 text-primary-300">{user.vipLevel}</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => logout()}
              className="text-dark-300 hover:text-white"
            >
              <FaSignOutAlt className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {/* User Info Section */}
        <div className="px-4 sm:px-0 mb-8">
          <div className="bg-gradient-primary rounded-xl shadow-xl px-6 py-6">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between">
              <div className="mb-4 md:mb-0">
                <p className="text-dark-300 text-sm mb-1">Добро пожаловать</p>
                <h2 className="text-2xl font-bold text-white">{user.username}</h2>
                <p className="text-dark-200 text-sm mt-1">{user.email}</p>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  className="bg-secondary-500 hover:bg-secondary-400 text-white"
                  onClick={() => setIsDepositModalOpen(true)}
                >
                  <FaPlus className="mr-2" /> Пополнить
                </Button>
                <Button
                  variant="outline"
                  className="bg-dark-700 hover:bg-dark-600 text-white border-dark-600"
                  onClick={() => setIsWithdrawalModalOpen(true)}
                >
                  <FaArrowRight className="mr-2" /> Вывести
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 px-4 sm:px-0">
          {/* Balance Card */}
          <Card className="bg-dark-800 border-dark-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">Баланс</h3>
                <div className="bg-primary-800 p-2 rounded-lg">
                  <FaWallet className="text-primary-400" />
                </div>
              </div>
              <p className="text-3xl font-bold text-white mb-2">{user.balance.toFixed(2)} USDT</p>
              <div className="text-xs text-dark-300 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>Последнее обновление: {formatDate(new Date())}</span>
              </div>
              <Separator className="my-4 bg-dark-700" />
              <div className="flex justify-between text-sm">
                <span className="text-dark-300">Доступно для вывода:</span>
                <span className="text-white font-medium">{availableForWithdrawal.toFixed(2)} USDT</span>
              </div>
            </CardContent>
          </Card>

          {/* VIP Status Card */}
          <Card className="bg-dark-800 border-dark-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">VIP Статус</h3>
                <div className="bg-primary-800 p-2 rounded-lg">
                  <FaCrown className="text-primary-400" />
                </div>
              </div>
              <div className="flex items-center mb-4">
                <div className="bg-primary-700 text-white text-lg font-bold w-10 h-10 rounded-full flex items-center justify-center mr-3">
                  {user.vipLevel}
                </div>
                <div>
                  <p className="text-white font-medium">VIP {user.vipLevel}</p>
                  <p className="text-xs text-dark-300">Ежедневный доход: {getDailyRateByVipLevel(user.vipLevel)}%</p>
                </div>
              </div>
              {currentVipLevel < 6 && (
                <div className="mb-2">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-dark-300">Прогресс до VIP {nextVipLevel}</span>
                    <span className="text-dark-300">{totalInvested} / {requiredForNextLevel} USDT</span>
                  </div>
                  <Progress value={progressPercentage} className="h-2 bg-dark-700" indicatorClassName="bg-secondary-500" />
                </div>
              )}
              {currentVipLevel < 6 ? (
                <Button
                  className="mt-4 w-full bg-primary-700 hover:bg-primary-600 text-white"
                  onClick={() => setIsDepositModalOpen(true)}
                >
                  Повысить уровень
                </Button>
              ) : (
                <div className="mt-4 text-center text-dark-300 text-sm">
                  <p>Вы достигли максимального VIP уровня</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Referral Card */}
          <Card className="bg-dark-800 border-dark-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-medium text-white">Рефералы</h3>
                <div className="bg-primary-800 p-2 rounded-lg">
                  <FaUsers className="text-primary-400" />
                </div>
              </div>
              <p className="text-3xl font-bold text-white mb-2">{referrals?.count || 0}</p>
              <p className="text-sm text-dark-300 mb-4">Активных рефералов</p>
              <div className="bg-dark-700 rounded-lg p-3 mb-4">
                <p className="text-xs text-dark-300 mb-1">Ваша реферальная ссылка:</p>
                <div className="flex items-center">
                  <input
                    type="text"
                    value={`${window.location.origin}/register?ref=${user.referralCode}`}
                    readOnly
                    className="text-white bg-dark-800 rounded py-1 px-2 text-xs flex-grow mr-2 border border-dark-600"
                  />
                  <Button
                    variant="secondary"
                    size="icon"
                    className="bg-primary-700 text-white hover:bg-primary-600"
                    onClick={handleCopyReferralLink}
                  >
                    <FaCopy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-dark-300">Заработано:</span>
                <span className="text-white font-medium">{referrals?.totalEarned.toFixed(2) || "0.00"} USDT</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Statistics and History */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6 px-4 sm:px-0">
          {/* Investment Stats */}
          <div className="lg:col-span-2">
            <Card className="bg-dark-800 border-dark-700">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium text-white mb-6">Статистика инвестиций</h3>
                
                <div className="space-y-6">
                  {/* Current Investments */}
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="text-white font-medium">Текущие инвестиции</h4>
                      <span className="text-xs text-dark-300">Всего: {totalInvested.toFixed(2)} USDT</span>
                    </div>
                    
                    <div className="space-y-3">
                      {investments && investments.length > 0 ? (
                        investments.map((investment) => (
                          <div key={investment.id} className="bg-dark-700 rounded-lg p-4">
                            <div className="flex justify-between items-center mb-2">
                              <div>
                                <span className="text-white font-medium">Инвестиция #{investment.id}</span>
                                <span className="ml-2 text-xs bg-green-900 text-green-300 px-2 py-0.5 rounded">{investment.status === 'active' ? 'Активна' : 'Завершена'}</span>
                              </div>
                              <span className="text-white font-medium">{investment.amount.toFixed(2)} USDT</span>
                            </div>
                            <div className="flex justify-between text-xs">
                              <span className="text-dark-300">Дата: {formatDate(new Date(investment.createdAt))}</span>
                              <span className="text-green-400">+{getDailyRateByVipLevel(user.vipLevel)}% в день</span>
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="bg-dark-700 rounded-lg p-4 text-center">
                          <p className="text-dark-300">У вас пока нет инвестиций</p>
                          <Button 
                            variant="outline" 
                            className="mt-2 border-primary-600 text-primary-400 hover:bg-primary-900 hover:text-primary-300"
                            onClick={() => {
                              if (user.balance >= 50) {
                                createInvestment({ amount: 50 });
                              } else {
                                setIsDepositModalOpen(true);
                              }
                            }}
                          >
                            Создать первую инвестицию
                          </Button>
                        </div>
                      )}
                      
                      {investments && investments.length > 0 && (
                        <div className="text-center mt-2">
                          <Button 
                            variant="outline" 
                            className="border-primary-600 text-primary-400 hover:bg-primary-900 hover:text-primary-300"
                            onClick={handleSimulateDailyProfit}
                          >
                            Получить ежедневный доход
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Earned */}
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <h4 className="text-white font-medium">Заработано</h4>
                      <span className="text-xs text-dark-300">За всё время</span>
                    </div>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="bg-dark-700 rounded-lg p-3 text-center">
                        <p className="text-green-400 font-bold text-lg">{weeklyProfit.toFixed(2)} USDT</p>
                        <p className="text-xs text-dark-300">За 7 дней</p>
                      </div>
                      
                      <div className="bg-dark-700 rounded-lg p-3 text-center">
                        <p className="text-green-400 font-bold text-lg">{monthlyProfit.toFixed(2)} USDT</p>
                        <p className="text-xs text-dark-300">За 30 дней</p>
                      </div>
                      
                      <div className="bg-dark-700 rounded-lg p-3 text-center">
                        <p className="text-green-400 font-bold text-lg">{totalProfit.toFixed(2)} USDT</p>
                        <p className="text-xs text-dark-300">Всего</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* History */}
          <div>
            <Card className="bg-dark-800 border-dark-700">
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-lg font-medium text-white">История операций</h3>
                  <Button variant="link" className="text-xs text-secondary-400 p-0">Смотреть все</Button>
                </div>
                
                <div className="space-y-4">
                  {transactions && transactions.length > 0 ? (
                    transactions.slice(0, 5).map((transaction) => {
                      const isPositive = transaction.amount > 0;
                      let icon, bgColor, textColor, label;
                      
                      switch (transaction.type) {
                        case 'deposit':
                          icon = <FaArrowDown />;
                          bgColor = 'bg-green-900';
                          textColor = 'text-green-400';
                          label = 'Депозит';
                          break;
                        case 'withdrawal':
                          icon = <FaArrowRight />;
                          bgColor = 'bg-red-900';
                          textColor = 'text-red-400';
                          label = 'Вывод';
                          break;
                        case 'profit':
                          icon = <FaCoins />;
                          bgColor = 'bg-primary-900';
                          textColor = 'text-primary-400';
                          label = 'Доход';
                          break;
                        case 'referral':
                          icon = <FaUsers />;
                          bgColor = 'bg-blue-900';
                          textColor = 'text-blue-400';
                          label = 'Реферальный бонус';
                          break;
                        default:
                          icon = <FaCoins />;
                          bgColor = 'bg-primary-900';
                          textColor = 'text-primary-400';
                          label = 'Транзакция';
                      }

                      return (
                        <div key={transaction.id} className="flex items-center">
                          <div className={`w-8 h-8 ${bgColor} rounded-full flex items-center justify-center mr-3`}>
                            <span className={textColor}>{icon}</span>
                          </div>
                          <div className="flex-grow">
                            <p className="text-white font-medium">{label}</p>
                            <p className="text-xs text-dark-300">{formatDate(new Date(transaction.createdAt))}</p>
                          </div>
                          <div className="text-right">
                            <p className={`${isPositive ? 'text-green-400' : 'text-red-400'} font-medium`}>
                              {isPositive ? '+' : ''}{transaction.amount.toFixed(2)} USDT
                            </p>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center text-dark-300 py-4">
                      <p>Нет истории операций</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      {/* Modals */}
      <WalletModal 
        isOpen={isWalletModalOpen} 
        onClose={() => setIsWalletModalOpen(false)} 
      />
      
      <DepositModal 
        isOpen={isDepositModalOpen} 
        onClose={() => setIsDepositModalOpen(false)} 
        onDeposit={makeDeposit}
      />
      
      <WithdrawalModal 
        isOpen={isWithdrawalModalOpen} 
        onClose={() => setIsWithdrawalModalOpen(false)} 
        onWithdraw={makeWithdrawal}
        balance={user.balance}
        lastWithdrawal={user.lastWithdrawal}
      />
    </div>
  );
};

export default DashboardPage;
