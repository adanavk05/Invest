import React, { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import VipLevelCard from '@/components/VipLevelCard';
import { useAuth } from '@/hooks/useAuth';
import {
  FaChartLine,
  FaShieldAlt,
  FaUsers,
  FaArrowRight,
  FaWallet,
} from 'react-icons/fa';

const HomePage: React.FC = () => {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  const handleInvestClick = () => {
    if (user) {
      setLocation('/dashboard');
    } else {
      setLocation('/register');
    }
  };

  return (
    <div className="animate-fade-in">
      {/* Hero Section */}
      <div className="relative">
        <div className="relative h-[500px] bg-gradient-hero overflow-hidden">
          <div className="absolute inset-0 opacity-30" 
               style={{
                 backgroundImage: 'url("https://images.unsplash.com/photo-1518546305927-5a555bb7020d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080")',
                 backgroundSize: 'cover',
                 backgroundPosition: 'center'
               }} />
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
            <div className="text-center md:text-left md:w-2/3">
              <h1 className="text-4xl md:text-5xl font-bold font-heading text-white leading-tight">
                Инвестируйте в будущее с <span className="text-secondary-400">CryptoVest</span>
              </h1>
              <p className="mt-4 text-lg md:text-xl text-dark-100 max-w-2xl">
                Надежная платформа для инвестиций в криптовалюту с стабильным ежедневным доходом и впечатляющей реферальной программой.
              </p>
              <div className="mt-8">
                <Button 
                  size="lg" 
                  className="bg-secondary-500 hover:bg-secondary-400 text-white font-bold py-3 px-8 rounded-lg text-lg shadow-lg transform transition hover:scale-105" 
                  onClick={handleInvestClick}
                >
                  Инвестировать сейчас
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-16 bg-dark-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold font-heading text-white mb-8">Почему выбирают нас</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-10">
            <div className="bg-dark-700 p-6 rounded-xl shadow-md transform transition hover:scale-105">
              <div className="h-12 w-12 bg-primary-700 rounded-full flex items-center justify-center mb-4">
                <FaChartLine className="text-white text-xl" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Стабильный доход</h3>
              <p className="text-dark-200">От 1.2% до 2.2% ежедневно в зависимости от вашего VIP уровня.</p>
            </div>
            
            <div className="bg-dark-700 p-6 rounded-xl shadow-md transform transition hover:scale-105">
              <div className="h-12 w-12 bg-primary-700 rounded-full flex items-center justify-center mb-4">
                <FaShieldAlt className="text-white text-xl" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Безопасность</h3>
              <p className="text-dark-200">Интеграция с проверенными кошельками Trust Wallet и MetaMask.</p>
            </div>
            
            <div className="bg-dark-700 p-6 rounded-xl shadow-md transform transition hover:scale-105">
              <div className="h-12 w-12 bg-primary-700 rounded-full flex items-center justify-center mb-4">
                <FaUsers className="text-white text-xl" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Реферальная программа</h3>
              <p className="text-dark-200">Получайте 15 USDT за каждого приглашенного пользователя.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Investment Levels */}
      <div className="py-16 bg-gradient-to-b from-dark-900 to-dark-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold font-heading text-white mb-4">VIP уровни инвестирования</h2>
            <p className="text-dark-200 max-w-2xl mx-auto">Выберите инвестиционный план, который подходит именно вам</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <VipLevelCard 
              level={1} 
              dailyReturn={1.2} 
              minDeposit={50} 
              popular={false} 
              features={[
                "Минимальный депозит: 50 USDT",
                "Еженедельный вывод средств"
              ]} 
            />
            
            <VipLevelCard 
              level={2} 
              dailyReturn={1.4} 
              minDeposit={300} 
              popular={false} 
              features={[
                "Минимальный депозит: 300 USDT",
                "Еженедельный вывод средств",
                "Приоритетная поддержка"
              ]} 
            />
            
            <VipLevelCard 
              level={3} 
              dailyReturn={1.6} 
              minDeposit={1000} 
              popular={true} 
              features={[
                "Минимальный депозит: 1,000 USDT",
                "Еженедельный вывод средств",
                "Бонус реферала +3%",
                "VIP поддержка 24/7"
              ]} 
            />
          </div>
          
          <div className="text-center mt-8">
            <Link href="#">
              <a className="text-secondary-400 hover:text-secondary-300 font-medium inline-flex items-center">
                Посмотреть все VIP уровни
                <FaArrowRight className="ml-2" />
              </a>
            </Link>
          </div>
        </div>
      </div>

      {/* Wallet Integration */}
      <div className="py-16 bg-dark-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold font-heading text-white mb-4">Поддерживаемые кошельки</h2>
            <p className="text-dark-200 max-w-2xl mx-auto">Легкая интеграция с вашими любимыми криптокошельками</p>
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-center space-y-8 md:space-y-0 md:space-x-12">
            <div className="text-center">
              <div className="w-24 h-24 mx-auto rounded-xl shadow-lg mb-4 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1622630998477-20aa696ecb05?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" 
                  alt="Trust Wallet интерфейс" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-bold text-white">Trust Wallet</h3>
              <p className="text-dark-300 mt-2">Безопасный мультивалютный кошелек</p>
            </div>
            
            <div className="text-center">
              <div className="w-24 h-24 mx-auto rounded-xl shadow-lg mb-4 overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1622630998477-20aa696ecb05?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&h=300" 
                  alt="MetaMask интерфейс" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-bold text-white">MetaMask</h3>
              <p className="text-dark-300 mt-2">Популярный ETH-совместимый кошелек</p>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-12 bg-gradient-cta">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold font-heading text-white mb-4">Готовы начать инвестировать?</h2>
          <p className="text-dark-100 max-w-2xl mx-auto mb-8">Присоединяйтесь к тысячам инвесторов, которые уже получают стабильный доход с CryptoVest</p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
            <Button 
              className="bg-secondary-500 hover:bg-secondary-400 text-white font-bold py-3 px-8 rounded-lg text-lg shadow-lg"
              onClick={() => setLocation('/register')}
            >
              Зарегистрироваться
            </Button>
            <Button 
              className="bg-transparent border-2 border-white hover:bg-white hover:text-primary-800 text-white font-bold py-3 px-8 rounded-lg text-lg"
              variant="outline"
              onClick={() => setLocation('#')}
            >
              Узнать больше
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;
