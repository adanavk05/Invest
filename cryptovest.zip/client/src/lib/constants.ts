// VIP levels and their corresponding daily return rates
export const VIP_LEVELS = [
  { level: 1, rate: 1.2, minDeposit: 50 },
  { level: 2, rate: 1.4, minDeposit: 300 },
  { level: 3, rate: 1.6, minDeposit: 1000 },
  { level: 4, rate: 1.8, minDeposit: 2000 },
  { level: 5, rate: 2.0, minDeposit: 3000 },
  { level: 6, rate: 2.2, minDeposit: 5000 }
];

// Minimum amounts for deposits and withdrawals
export const MIN_DEPOSIT = 50; // USDT
export const MIN_WITHDRAWAL = 70; // USDT

// Withdrawal interval in days
export const WITHDRAWAL_INTERVAL_DAYS = 7;

// Referral bonus amount
export const REFERRAL_BONUS = 15; // USDT

// Supported wallet types
export const WALLET_TYPES = {
  TRUST_WALLET: 'Trust Wallet',
  METAMASK: 'MetaMask'
};

// Transaction types
export const TRANSACTION_TYPES = {
  DEPOSIT: 'deposit',
  WITHDRAWAL: 'withdrawal',
  INVESTMENT: 'investment',
  PROFIT: 'profit',
  REFERRAL: 'referral'
};

// Transaction statuses
export const TRANSACTION_STATUSES = {
  PENDING: 'pending',
  COMPLETED: 'completed',
  REJECTED: 'rejected'
};

// Investment statuses
export const INVESTMENT_STATUSES = {
  ACTIVE: 'active',
  COMPLETED: 'completed'
};
