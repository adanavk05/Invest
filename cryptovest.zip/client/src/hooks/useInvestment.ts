import { useState, useEffect } from 'react';
import { useAuth } from './useAuth';
import { apiRequest } from '@/lib/queryClient';
import { queryClient } from '@/lib/queryClient';
import { Investment, Transaction } from '@shared/schema';
import { VIP_LEVELS } from '@/lib/constants';

interface ReferralData {
  referrals: any[];
  count: number;
  totalEarned: number;
}

interface InvestmentHook {
  investments: Investment[] | null;
  transactions: Transaction[] | null;
  referrals: ReferralData | null;
  isLoading: boolean;
  error: Error | null;
  createInvestment: (data: { amount: number }) => Promise<void>;
  makeDeposit: (amount: number) => Promise<void>;
  makeWithdrawal: (amount: number, walletAddress: string) => Promise<void>;
  simulateDailyProfit: () => Promise<{ profit: number; rate: number; totalInvested: number }>;
}

export function useInvestment(): InvestmentHook {
  const { user, refetchUser } = useAuth();
  const [investments, setInvestments] = useState<Investment[] | null>(null);
  const [transactions, setTransactions] = useState<Transaction[] | null>(null);
  const [referrals, setReferrals] = useState<ReferralData | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchAllData = async () => {
    if (!user) {
      setIsLoading(false);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      // Fetch investments
      const investmentsResponse = await apiRequest('GET', '/api/investments');
      const investmentsData = await investmentsResponse.json();
      setInvestments(investmentsData);

      // Fetch transactions
      const transactionsResponse = await apiRequest('GET', '/api/transactions');
      const transactionsData = await transactionsResponse.json();
      setTransactions(transactionsData);

      // Fetch referrals
      const referralsResponse = await apiRequest('GET', '/api/referrals');
      const referralsData = await referralsResponse.json();
      setReferrals(referralsData);
    } catch (err) {
      setError(err instanceof Error ? err : new Error('Ошибка при загрузке данных'));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, [user]);

  const createInvestment = async (data: { amount: number }) => {
    try {
      await apiRequest('POST', '/api/investments', data);
      // Refetch data
      await fetchAllData();
      await refetchUser();
    } catch (err) {
      throw err instanceof Error ? err : new Error('Ошибка при создании инвестиции');
    }
  };

  const makeDeposit = async (amount: number) => {
    try {
      await apiRequest('POST', '/api/transactions/deposit', { amount });
      // Refetch data
      await fetchAllData();
      await refetchUser();
    } catch (err) {
      throw err instanceof Error ? err : new Error('Ошибка при пополнении баланса');
    }
  };

  const makeWithdrawal = async (amount: number, walletAddress: string) => {
    try {
      await apiRequest('POST', '/api/transactions/withdraw', { amount, walletAddress });
      // Refetch data
      await fetchAllData();
      await refetchUser();
    } catch (err) {
      throw err instanceof Error ? err : new Error('Ошибка при выводе средств');
    }
  };

  const simulateDailyProfit = async () => {
    try {
      const response = await apiRequest('POST', '/api/simulate-daily-profit');
      const data = await response.json();
      // Refetch data
      await fetchAllData();
      await refetchUser();
      return data;
    } catch (err) {
      throw err instanceof Error ? err : new Error('Ошибка при начислении ежедневного дохода');
    }
  };

  return {
    investments,
    transactions,
    referrals,
    isLoading,
    error,
    createInvestment,
    makeDeposit,
    makeWithdrawal,
    simulateDailyProfit,
  };
}
