import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { FaCoins } from 'react-icons/fa';

const Navbar: React.FC = () => {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleLogout = async () => {
    await logout();
  };

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  // Close mobile menu when location changes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  if (!mounted) return null;

  return (
    <nav className="bg-dark-800 border-b border-dark-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/">
              <a className="flex-shrink-0 flex items-center">
                <FaCoins className="text-secondary-400 mr-2 text-2xl" />
                <span className="font-heading font-bold text-xl text-white">CryptoVest</span>
              </a>
            </Link>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <Link href="/">
                <a className={`px-1 pt-1 border-b-2 font-medium text-sm ${location === '/' ? 'border-primary-500 text-white' : 'border-transparent text-dark-300 hover:border-dark-400 hover:text-dark-200'}`}>
                  Главная
                </a>
              </Link>
              {!user && (
                <>
                  <Link href="/register">
                    <a className={`px-1 pt-1 border-b-2 font-medium text-sm ${location === '/register' ? 'border-primary-500 text-white' : 'border-transparent text-dark-300 hover:border-dark-400 hover:text-dark-200'}`}>
                      Регистрация
                    </a>
                  </Link>
                  <Link href="/login">
                    <a className={`px-1 pt-1 border-b-2 font-medium text-sm ${location === '/login' ? 'border-primary-500 text-white' : 'border-transparent text-dark-300 hover:border-dark-400 hover:text-dark-200'}`}>
                      Вход
                    </a>
                  </Link>
                </>
              )}
              {user && (
                <Link href="/dashboard">
                  <a className={`px-1 pt-1 border-b-2 font-medium text-sm ${location === '/dashboard' ? 'border-primary-500 text-white' : 'border-transparent text-dark-300 hover:border-dark-400 hover:text-dark-200'}`}>
                    Кабинет
                  </a>
                </Link>
              )}
            </div>
          </div>
          
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            {user ? (
              <div className="flex items-center gap-4">
                {user.balance !== undefined && (
                  <span className="text-dark-200 text-sm">
                    Баланс: <span className="text-white font-medium">{user.balance.toFixed(2)} USDT</span>
                  </span>
                )}
                <Button variant="destructive" size="sm" onClick={handleLogout}>
                  Выйти
                </Button>
              </div>
            ) : (
              <Link href="/login">
                <Button className="bg-primary-700 text-white hover:bg-primary-600">
                  Вход
                </Button>
              </Link>
            )}
          </div>
          
          <div className="flex items-center sm:hidden">
            <button 
              onClick={toggleMobileMenu}
              className="inline-flex items-center justify-center p-2 rounded-md text-dark-400 hover:text-white hover:bg-dark-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
            >
              <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link href="/">
              <a className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${location === '/' ? 'bg-primary-700 text-white border-primary-500' : 'border-transparent text-dark-300 hover:bg-dark-700 hover:border-dark-500 hover:text-white'}`}>
                Главная
              </a>
            </Link>
            {!user && (
              <>
                <Link href="/register">
                  <a className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${location === '/register' ? 'bg-primary-700 text-white border-primary-500' : 'border-transparent text-dark-300 hover:bg-dark-700 hover:border-dark-500 hover:text-white'}`}>
                    Регистрация
                  </a>
                </Link>
                <Link href="/login">
                  <a className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${location === '/login' ? 'bg-primary-700 text-white border-primary-500' : 'border-transparent text-dark-300 hover:bg-dark-700 hover:border-dark-500 hover:text-white'}`}>
                    Вход
                  </a>
                </Link>
              </>
            )}
            {user && (
              <>
                <Link href="/dashboard">
                  <a className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${location === '/dashboard' ? 'bg-primary-700 text-white border-primary-500' : 'border-transparent text-dark-300 hover:bg-dark-700 hover:border-dark-500 hover:text-white'}`}>
                    Кабинет
                  </a>
                </Link>
                <button 
                  onClick={handleLogout}
                  className="w-full text-left block pl-3 pr-4 py-2 border-l-4 border-transparent text-dark-300 hover:bg-dark-700 hover:border-destructive hover:text-white text-base font-medium"
                >
                  Выйти
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
