import { 
  User, InsertUser, Investment, InsertInvestment, 
  Transaction, InsertTransaction, Referral, InsertReferral 
} from "@shared/schema";
import { randomBytes } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByReferralCode(code: string): Promise<User | undefined>;
  createUser(user: InsertUser, referralCode?: string): Promise<User>;
  updateUserBalance(id: number, amount: number): Promise<User>;
  updateUserVipLevel(id: number, level: number): Promise<User>;
  updateUserLastWithdrawal(id: number): Promise<User>;
  
  // Investment methods
  getInvestments(userId: number): Promise<Investment[]>;
  createInvestment(investment: InsertInvestment): Promise<Investment>;
  
  // Transaction methods
  getTransactions(userId: number): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransactionStatus(id: number, status: string): Promise<Transaction>;
  
  // Referral methods
  getReferrals(referrerId: number): Promise<Referral[]>;
  createReferral(referral: InsertReferral): Promise<Referral>;
  markReferralPaid(id: number): Promise<Referral>;
  getReferralCount(referrerId: number): Promise<number>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private investments: Map<number, Investment>;
  private transactions: Map<number, Transaction>;
  private referrals: Map<number, Referral>;
  private userIdCounter: number;
  private investmentIdCounter: number;
  private transactionIdCounter: number;
  private referralIdCounter: number;

  constructor() {
    this.users = new Map();
    this.investments = new Map();
    this.transactions = new Map();
    this.referrals = new Map();
    this.userIdCounter = 1;
    this.investmentIdCounter = 1;
    this.transactionIdCounter = 1;
    this.referralIdCounter = 1;
  }

  private generateReferralCode(): string {
    return randomBytes(4).toString('hex');
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByReferralCode(code: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.referralCode === code);
  }

  async createUser(userData: InsertUser, referralCode?: string): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    
    // Generate unique referral code
    const userReferralCode = this.generateReferralCode();
    
    const user: User = {
      ...userData,
      id,
      referralCode: userReferralCode,
      balance: 0,
      vipLevel: 1,
      createdAt: now,
      referredBy: referralCode || null,
      lastWithdrawal: null
    };
    
    this.users.set(id, user);
    return user;
  }

  async updateUserBalance(id: number, amount: number): Promise<User> {
    const user = await this.getUser(id);
    if (!user) throw new Error("Пользователь не найден");
    
    const updatedUser = { 
      ...user, 
      balance: user.balance + amount 
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserVipLevel(id: number, level: number): Promise<User> {
    const user = await this.getUser(id);
    if (!user) throw new Error("Пользователь не найден");
    
    const updatedUser = { 
      ...user, 
      vipLevel: level 
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserLastWithdrawal(id: number): Promise<User> {
    const user = await this.getUser(id);
    if (!user) throw new Error("Пользователь не найден");
    
    const updatedUser = { 
      ...user, 
      lastWithdrawal: new Date() 
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Investment methods
  async getInvestments(userId: number): Promise<Investment[]> {
    return Array.from(this.investments.values())
      .filter(investment => investment.userId === userId);
  }

  async createInvestment(investment: InsertInvestment): Promise<Investment> {
    const id = this.investmentIdCounter++;
    const now = new Date();
    
    const newInvestment: Investment = {
      ...investment,
      id,
      status: "active",
      createdAt: now
    };
    
    this.investments.set(id, newInvestment);
    return newInvestment;
  }

  // Transaction methods
  async getTransactions(userId: number): Promise<Transaction[]> {
    return Array.from(this.transactions.values())
      .filter(transaction => transaction.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = this.transactionIdCounter++;
    const now = new Date();
    
    const newTransaction: Transaction = {
      ...transaction,
      id,
      createdAt: now
    };
    
    this.transactions.set(id, newTransaction);
    return newTransaction;
  }

  async updateTransactionStatus(id: number, status: string): Promise<Transaction> {
    const transaction = this.transactions.get(id);
    if (!transaction) throw new Error("Транзакция не найдена");
    
    const updatedTransaction = { 
      ...transaction, 
      status 
    };
    
    this.transactions.set(id, updatedTransaction);
    return updatedTransaction;
  }

  // Referral methods
  async getReferrals(referrerId: number): Promise<Referral[]> {
    return Array.from(this.referrals.values())
      .filter(referral => referral.referrerId === referrerId);
  }

  async createReferral(referral: InsertReferral): Promise<Referral> {
    const id = this.referralIdCounter++;
    const now = new Date();
    
    const newReferral: Referral = {
      ...referral,
      id,
      bonusPaid: false,
      createdAt: now
    };
    
    this.referrals.set(id, newReferral);
    return newReferral;
  }

  async markReferralPaid(id: number): Promise<Referral> {
    const referral = this.referrals.get(id);
    if (!referral) throw new Error("Реферал не найден");
    
    const updatedReferral = { 
      ...referral, 
      bonusPaid: true 
    };
    
    this.referrals.set(id, updatedReferral);
    return updatedReferral;
  }

  async getReferralCount(referrerId: number): Promise<number> {
    const referrals = await this.getReferrals(referrerId);
    return referrals.length;
  }
}

export const storage = new MemStorage();
