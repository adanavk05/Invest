import React from 'react';
import { Link, useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { registerSchema } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { FaCoins, FaTelegram, FaWallet } from 'react-icons/fa';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';

type RegisterFormValues = {
  username: string;
  email: string;
  password: string;
  confirmPassword: string;
  referralCode?: string;
  terms: boolean;
};

const RegisterPage: React.FC = () => {
  const { toast } = useToast();
  const { register } = useAuth();
  const [, setLocation] = useLocation();

  const form = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      referralCode: '',
      terms: false,
    },
  });

  const onSubmit = async (data: RegisterFormValues) => {
    try {
      await register(data);
      toast({
        title: "Регистрация успешна",
        description: "Добро пожаловать в CryptoVest!",
      });
      setLocation('/dashboard');
    } catch (error) {
      toast({
        title: "Ошибка при регистрации",
        description: error.message || "Произошла ошибка. Пожалуйста, попробуйте снова.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 bg-dark-900 animate-fade-in">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <FaCoins className="text-secondary-400 text-3xl" />
        </div>
        <h2 className="mt-6 text-center text-3xl font-bold font-heading text-white">Регистрация аккаунта</h2>
        <p className="mt-2 text-center text-dark-300">
          Уже есть аккаунт?{' '}
          <Link href="/login">
            <a className="text-secondary-400 hover:text-secondary-300">Войти</a>
          </Link>
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-dark-800 py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="username"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-dark-200">Имя</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        className="bg-dark-700 border-dark-600 text-white placeholder-dark-400"
                        placeholder="Иван Петров"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-dark-200">Email</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="email"
                        className="bg-dark-700 border-dark-600 text-white placeholder-dark-400"
                        placeholder="ivanov@example.com"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-dark-200">Пароль</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="password"
                        className="bg-dark-700 border-dark-600 text-white placeholder-dark-400"
                        placeholder="••••••••"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="confirmPassword"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-dark-200">Подтверждение пароля</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="password"
                        className="bg-dark-700 border-dark-600 text-white placeholder-dark-400"
                        placeholder="••••••••"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="referralCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-dark-200">Реферальный код (если есть)</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        className="bg-dark-700 border-dark-600 text-white placeholder-dark-400"
                        placeholder="abcd1234"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="terms"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                        className="data-[state=checked]:bg-primary-600 border-dark-500 bg-dark-700"
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel className="text-dark-300">
                        Я согласен с <a href="#" className="text-secondary-400 hover:text-secondary-300">условиями использования</a>
                      </FormLabel>
                      <FormMessage />
                    </div>
                  </FormItem>
                )}
              />

              <Button type="submit" className="w-full bg-primary-600 hover:bg-primary-500">
                Зарегистрироваться
              </Button>
            </form>
          </Form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <Separator className="w-full border-dark-600" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-dark-800 text-dark-400">Или продолжить с</span>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3">
              <Button variant="outline" className="w-full bg-dark-700 text-dark-200 hover:bg-dark-600 border-dark-600">
                <FaTelegram className="mr-2" />
                Telegram
              </Button>
              <Button variant="outline" className="w-full bg-dark-700 text-dark-200 hover:bg-dark-600 border-dark-600">
                <FaWallet className="mr-2" />
                MetaMask
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
