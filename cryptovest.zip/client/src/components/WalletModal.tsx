import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { FaWallet, FaTimes, FaChevronRight } from 'react-icons/fa';
import { useToast } from '@/hooks/use-toast';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const WalletModal: React.FC<WalletModalProps> = ({ isOpen, onClose }) => {
  const { toast } = useToast();

  const handleConnectWallet = (walletType: string) => {
    // In a real app, this would connect to the wallet
    toast({
      title: "Подключение кошелька",
      description: `Имитация подключения ${walletType}. В реальном приложении здесь была бы интеграция с кошельком.`,
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-dark-800 text-white border-dark-700 sm:max-w-md">
        <DialogHeader>
          <div className="flex justify-between items-center mb-2">
            <DialogTitle className="text-xl font-bold text-white">Подключение кошелька</DialogTitle>
            <DialogClose className="text-dark-400 hover:text-white">
              <FaTimes />
            </DialogClose>
          </div>
          <DialogDescription className="text-dark-300">
            Выберите кошелек для подключения к платформе:
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <Button
            variant="outline"
            className="w-full bg-dark-700 hover:bg-dark-600 border-dark-600 justify-between text-left h-auto py-4"
            onClick={() => handleConnectWallet('Trust Wallet')}
          >
            <div className="flex items-center">
              <div className="w-10 h-10 bg-blue-900 rounded-full flex items-center justify-center mr-3">
                <FaWallet className="text-blue-400" />
              </div>
              <span className="text-white font-medium">Trust Wallet</span>
            </div>
            <FaChevronRight className="text-dark-400" />
          </Button>
          
          <Button
            variant="outline"
            className="w-full bg-dark-700 hover:bg-dark-600 border-dark-600 justify-between text-left h-auto py-4"
            onClick={() => handleConnectWallet('MetaMask')}
          >
            <div className="flex items-center">
              <div className="w-10 h-10 bg-orange-900 rounded-full flex items-center justify-center mr-3">
                <FaWallet className="text-orange-400" />
              </div>
              <span className="text-white font-medium">MetaMask</span>
            </div>
            <FaChevronRight className="text-dark-400" />
          </Button>
        </div>
        
        <div className="mt-6 pt-6 border-t border-dark-700">
          <p className="text-xs text-dark-400 text-center">
            Подключая кошелек, вы соглашаетесь с условиями использования платформы CryptoVest
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default WalletModal;
