import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import { useLocation } from 'wouter';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [location] = useLocation();
  const isDashboard = location === '/dashboard';

  return (
    <div className="flex flex-col min-h-screen bg-dark-900 text-dark-50">
      <Navbar />
      <main className="flex-grow">
        {children}
      </main>
      {!isDashboard && <Footer />}
    </div>
  );
};

export default Layout;
