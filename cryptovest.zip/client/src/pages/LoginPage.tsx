import React from 'react';
import { Link, useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { loginSchema } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { FaCoins, FaWallet } from 'react-icons/fa';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';

type LoginFormValues = {
  email: string;
  password: string;
  remember: boolean;
};

const LoginPage: React.FC = () => {
  const { toast } = useToast();
  const { login } = useAuth();
  const [, setLocation] = useLocation();

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema.extend({
      remember: Boolean,
    })),
    defaultValues: {
      email: '',
      password: '',
      remember: false,
    },
  });

  const onSubmit = async (data: LoginFormValues) => {
    try {
      await login(data.email, data.password);
      toast({
        title: "Вход выполнен успешно",
        description: "Добро пожаловать в личный кабинет",
      });
      setLocation('/dashboard');
    } catch (error) {
      toast({
        title: "Ошибка при входе",
        description: error.message || "Неверный email или пароль",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center py-12 sm:px-6 lg:px-8 bg-dark-900 animate-fade-in">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <FaCoins className="text-secondary-400 text-3xl" />
        </div>
        <h2 className="mt-6 text-center text-3xl font-bold font-heading text-white">Вход в аккаунт</h2>
        <p className="mt-2 text-center text-dark-300">
          Нет аккаунта?{' '}
          <Link href="/register">
            <a className="text-secondary-400 hover:text-secondary-300">Зарегистрироваться</a>
          </Link>
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-dark-800 py-8 px-4 shadow sm:rounded-lg sm:px-10">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-dark-200">Email</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="email"
                        className="bg-dark-700 border-dark-600 text-white placeholder-dark-400"
                        placeholder="ivanov@example.com"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-dark-200">Пароль</FormLabel>
                    <FormControl>
                      <Input
                        {...field}
                        type="password"
                        className="bg-dark-700 border-dark-600 text-white placeholder-dark-400"
                        placeholder="••••••••"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex items-center justify-between">
                <FormField
                  control={form.control}
                  name="remember"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          className="data-[state=checked]:bg-primary-600 border-dark-500 bg-dark-700"
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="text-dark-300">
                          Запомнить меня
                        </FormLabel>
                      </div>
                    </FormItem>
                  )}
                />

                <div className="text-sm">
                  <Link href="#">
                    <a className="text-secondary-400 hover:text-secondary-300">
                      Забыли пароль?
                    </a>
                  </Link>
                </div>
              </div>

              <Button type="submit" className="w-full bg-primary-600 hover:bg-primary-500">
                Войти
              </Button>
            </form>
          </Form>

          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <Separator className="w-full border-dark-600" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-dark-800 text-dark-400">Или войти с помощью</span>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-3">
              <Button variant="outline" className="w-full bg-dark-700 text-dark-200 hover:bg-dark-600 border-dark-600">
                <FaWallet className="mr-2" />
                Trust Wallet
              </Button>
              <Button variant="outline" className="w-full bg-dark-700 text-dark-200 hover:bg-dark-600 border-dark-600">
                <FaWallet className="mr-2" />
                MetaMask
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
