
// Функция для получения цен BTC и ETH с CoinGecko API
async function fetchCryptoPrices() {
  try {
    const response = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd');
    const data = await response.json();
    document.getElementById('btcPrice').textContent = data.bitcoin.usd.toFixed(2);
    document.getElementById('ethPrice').textContent = data.ethereum.usd.toFixed(2);
  } catch (error) {
    document.getElementById('btcPrice').textContent = 'Ошибка загрузки';
    document.getElementById('ethPrice').textContent = 'Ошибка загрузки';
  }
}

// Обработка формы регистрации
document.getElementById('registerForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const email = document.getElementById('email').value.trim();
  if (email) {
    alert('Спасибо за регистрацию, ' + email + '! Реферальный бонус - 15 USDT за каждого приглашённого.');
    this.reset();
  }
});

// Обработчики кнопок ввода/вывода средств (имитация)
document.getElementById('depositBtn').addEventListener('click', () => {
  alert('Функция ввода средств пока не реализована.');
});
document.getElementById('withdrawBtn').addEventListener('click', () => {
  alert('Функция вывода средств пока не реализована.');
});

// Загрузка цен при открытии страницы и обновление каждые 60 секунд
fetchCryptoPrices();
setInterval(fetchCryptoPrices, 60000);
