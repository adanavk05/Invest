import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { FaTimes, FaCopy, FaExclamationTriangle } from 'react-icons/fa';
import { useToast } from '@/hooks/use-toast';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeposit: (amount: number) => Promise<void>;
}

const DepositModal: React.FC<DepositModalProps> = ({ isOpen, onClose, onDeposit }) => {
  const { toast } = useToast();
  const [amount, setAmount] = useState<number>(50);
  const [isProcessing, setIsProcessing] = useState(false);

  const walletAddress = "TXoVBQkNx8MVmRboru8UzCwkz35HjH83Vy"; // Example USDT TRC20 address

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(walletAddress);
    toast({
      title: "Скопировано!",
      description: "Адрес кошелька скопирован в буфер обмена",
    });
  };

  const handleConfirmDeposit = async () => {
    if (amount < 50) {
      toast({
        title: "Ошибка",
        description: "Минимальная сумма депозита 50 USDT",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    try {
      await onDeposit(amount);
      toast({
        title: "Депозит успешен",
        description: `${amount} USDT успешно добавлено на ваш счет`,
      });
      onClose();
    } catch (error) {
      toast({
        title: "Ошибка",
        description: error.message || "Произошла ошибка при пополнении",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-dark-800 text-white border-dark-700 sm:max-w-md">
        <DialogHeader>
          <div className="flex justify-between items-center mb-2">
            <DialogTitle className="text-xl font-bold text-white">Пополнение баланса</DialogTitle>
            <DialogClose className="text-dark-400 hover:text-white">
              <FaTimes />
            </DialogClose>
          </div>
        </DialogHeader>
        
        <div className="space-y-4">
          <div>
            <Label htmlFor="amount" className="text-dark-200">Сумма в USDT (TRC20)</Label>
            <Input 
              id="amount" 
              type="number" 
              min="50"
              value={amount} 
              onChange={(e) => setAmount(parseFloat(e.target.value))} 
              className="bg-dark-700 border-dark-600 text-white mt-1"
            />
            <p className="text-xs text-dark-400 mt-1">Минимальная сумма: 50 USDT</p>
          </div>
          
          <div>
            <p className="text-dark-300 mb-2">Отправьте USDT (TRC20) на указанный ниже адрес:</p>
            <Label className="block text-sm font-medium text-dark-300 mb-1">USDT TRC20 адрес:</Label>
            <div className="flex">
              <Input 
                value={walletAddress} 
                readOnly 
                className="bg-dark-700 border-dark-600 text-white rounded-r-none"
              />
              <Button 
                className="bg-primary-700 text-white hover:bg-primary-600 rounded-l-none"
                onClick={handleCopyAddress}
              >
                <FaCopy />
              </Button>
            </div>
          </div>
          
          <div className="bg-dark-700 rounded-lg p-4">
            <div className="flex items-center text-yellow-400 mb-2">
              <FaExclamationTriangle className="mr-2" />
              <span className="font-medium">Внимание!</span>
            </div>
            <p className="text-xs text-dark-300">
              Отправляйте только USDT по сети TRC20. Отправка через другие сети может привести к потере средств.
            </p>
          </div>
        </div>
        
        <Button
          className="w-full bg-primary-600 hover:bg-primary-500 text-white font-medium py-3 mt-4"
          onClick={handleConfirmDeposit}
          disabled={isProcessing || amount < 50}
        >
          {isProcessing ? "Обработка..." : "Я отправил USDT"}
        </Button>
      </DialogContent>
    </Dialog>
  );
};

export default DepositModal;
