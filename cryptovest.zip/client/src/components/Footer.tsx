import React from 'react';
import { Link } from 'wouter';
import { FaCoins, FaTelegram, FaTwitter, FaDiscord } from 'react-icons/fa';

const Footer: React.FC = () => {
  return (
    <footer className="bg-dark-900 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <FaCoins className="text-secondary-400 mr-2 text-2xl" />
              <span className="font-heading font-bold text-xl text-white">CryptoVest</span>
            </div>
            <p className="text-dark-300">Платформа для инвестиций в криптовалюту с фиксированным ежедневным доходом.</p>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Компания</h3>
            <ul className="space-y-2 text-dark-300">
              <li><Link href="#"><a className="hover:text-white">О нас</a></Link></li>
              <li><Link href="#"><a className="hover:text-white">Команда</a></Link></li>
              <li><Link href="#"><a className="hover:text-white">Карьера</a></Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Поддержка</h3>
            <ul className="space-y-2 text-dark-300">
              <li><Link href="#"><a className="hover:text-white">Помощь</a></Link></li>
              <li><Link href="#"><a className="hover:text-white">Контакты</a></Link></li>
              <li><Link href="#"><a className="hover:text-white">FAQ</a></Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-bold mb-4">Правовая информация</h3>
            <ul className="space-y-2 text-dark-300">
              <li><Link href="#"><a className="hover:text-white">Условия использования</a></Link></li>
              <li><Link href="#"><a className="hover:text-white">Политика конфиденциальности</a></Link></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-dark-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-dark-400">© {new Date().getFullYear()} CryptoVest. Все права защищены.</p>
          <div className="flex space-x-4 mt-4 md:mt-0">
            <a href="#" className="text-dark-400 hover:text-white">
              <FaTelegram size={20} />
            </a>
            <a href="#" className="text-dark-400 hover:text-white">
              <FaTwitter size={20} />
            </a>
            <a href="#" className="text-dark-400 hover:text-white">
              <FaDiscord size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
